<?php

class adminController {
    private $modelAdmin;
    public function __construct() {
        try {
          $this->modelAdmin=new admin();           
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
    public function insertSeller()
    {
        $usuario=$_POST['user']; 
        $password='A'.$_POST['user']; 
        $nombre=$_POST['nombre'];
        $apellido=$_POST['apellido'];
        $documento=$_POST['documento'];
        $direccion=$_POST['direccion'];
        $email=$_POST['email'];
        $telefono=$_POST['telefono'];
        $celular=$_POST['celular'];
        $zona=$_POST['zona'];
        
        $this->modelAdmin->insert('vendedor','(vendedor_usuario,vendedor_password,vendedor_nombre,vendedor_apellido,vendedor_documento,vendedor_direccion,vendedor_email,vendedor_telefono,vendedor_celular,vendedor_zona)'," VALUES ('$usuario','$password','$nombre','$apellido','$documento','$direccion','$email','$telefono','$celular','$zona')");
        header('location:?c=index&m=rol');       
        
    }
    public function querySeller($dato)
    {
        $this->modelIndex->queryLike('TABLE',"where DOCUMENTO2 LIKE  '%$dato%'");
    }
    
    public function formRegisterSeller()
    {
        require_once 'view/all/header.php';
       require_once 'view/all/navbar_rol.php';
       require_once 'view/form/form_register_seller.php';
       require_once 'view/all/footer.php';
    }
    public function listSeller()
    {
        require_once 'view/all/header.php';
       require_once 'view/all/navbar_rol.php';
       require_once 'view/form/list_Seller.php';
       require_once 'view/all/footer.php';
    }
    public function formRegisterProduct()
    {
        require_once 'view/all/header.php';
       require_once 'view/all/navbar_rol.php';
       require_once 'view/form/form_register_product.php';
       require_once 'view/all/footer.php';
    }
    public function listProduct()
    {
        require_once 'view/all/header.php';
       require_once 'view/all/navbar_rol.php';
       require_once 'view/form/list_Product.php';
       require_once 'view/all/footer.php';
    }
}
