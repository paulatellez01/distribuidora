<?php

class IndexController {
   //varibale donde guardo el todo el codigo del model - index
    private $modelIndex;
    //creacion de la variable privada 
    private $modelSecurity;
    public function __construct() {
        try {
            //genero la instancia de la clase index y la guardo en modelIndex
          $this->modelIndex=new index();
          $this->modelSecurity=new security();
         
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
    
    
   public function index()
   {
       require_once 'view/all/header.php';
       require_once 'view/index/index.php';
       require_once 'view/all/footer.php';
    }
    
    public function home()
    {
       require_once 'view/all/header.php';
       require_once 'view/all/navbar.php';
       require_once 'view/index/home.php';
       require_once 'view/all/footer.php';
    }
    
    public function rol()
    {
       require_once 'view/all/header.php';
       require_once 'view/all/navbar_rol.php';
       require_once 'view/index/rol.php';
       require_once 'view/all/footer.php';
    }
    public function productos()
    {
       require_once 'view/all/header.php';
       require_once 'view/all/navbar.php';
       require_once 'view/index/productos.php';
       require_once 'view/all/footer.php';
    }
    public function contacto()
    {
       require_once 'view/all/header.php';
       require_once 'view/all/navbar.php';
       require_once 'view/index/contacto.php';
       require_once 'view/all/footer.php';
    }
    
    public function validarData()
    {
        $_REQUEST['user'];
        $_REQUEST['password'];
        foreach ($this->modelIndex->queryId($_REQUEST['user']) as $r)
               
        if(($r->usuario_id==$_REQUEST['user'])&&($r->usuario_password==$_REQUEST['password']))
        {
            $data=array("usuario"=>$r->usuario_id,
                        "password"=>$r->usuario_password,
                        "rol"=>$r->usuario_rol);                       
            //INSANCIA DEL METODO DE SEGURIDAD QUE INICIALZIA LAS VARIABLES DE SESION
            $this->modelSecurity->iniciarSesion($data);
            header("location:?c=index&m=home");
        }
        else
        {
            header("location:?c=index&m=index");
        }
    
                
    }        
        
    
}
?>
