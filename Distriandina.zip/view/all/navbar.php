<div class="full">
    <div class="menu">
      <br><br><br><br><br><br><br>
        <ul>
            <li><a class="active"href="?c=index&m=home"><div class="cat"><h1><span class="glyphicon glyphicon-home" style="color: #cccccc"></span></h1></div></a></li>
            <li><a href="?c=index&m=rol"><div class="cat"><h1><span class="glyphicon glyphicon-user" style="color: #cccccc"></span></h1></div></a></li>
            <li><a href="?c=index&m=productos"><div class="cat"><h1><span class="glyphicon glyphicon-eye-open" style="color: #cccccc"></span></h1></div></a></li>
            <li><a href="?c=index&m=contacto"><div class="cat"><h1><span class="glyphicon glyphicon-envelope" style="color: #cccccc"></span></h1></div></a></li>
        </ul>
    </div>
