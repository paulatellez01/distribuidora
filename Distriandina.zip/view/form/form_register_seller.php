<div id="page-wrapper">
            <br>
<div class="container">
    <div class="container-fluid">
        <div class="jumbotron">
            <label><h5><b>Registrar Vendedor</b></h5></label>

            <br>
            <form action="?c=admin&m=insertSeller" method="post" enctype="multipart/form-data" autocomplete="off">
                <div class="form-group">
                    <label for="user">Usuario</label>
                    <input class="form-control" type="text" name="user" id="user" placeholder="Usuario">
                </div>
                
                <div class="form-group">
                    <label for="user">Nombre</label>
                    <input class="form-control" type="text" name="nombre" id="user" placeholder="Nombre">
                </div>

                <div class="form-group">
                    <label for="user">Apellido</label>
                    <input class="form-control" type="text" name="apellido" id="user" placeholder="Apellido">
                </div>
                
                <div class="form-group">
                    <label for="Documento">Documento</label>
                    <input class="form-control" type="text" name="documento" id="documento" placeholder="Documento">
                </div>
                
                <div class="form-group">
                    <label for="Direccion">Dirección</label>
                    <input class="form-control" type="text" name="direccion" id="direccion" placeholder="Dirección">
                </div>

                <div class="form-group">
                    <label for="Email">E-mail</label>
                    <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="E-mail">
                    <small id="emailHelp" class="form-text text-muted">Nunca compartiremos tu e-mail con ningúna persona.</small>
                </div>

                <div class="form-group">
                    <label for="tel">Telefono</label>
                    <input class="form-control" type="text" name="telefono" id="telefono" placeholder="Telefono">
                </div>

                <div class="form-group">
                    <label for="cel">Celular</label>
                    <input class="form-control" type="text" name="celular" id="celular" placeholder="Celular">
                </div>

                
                <!--
                <div class="form-group">
                    <label for="exampleSelect1">Genero</label>
                    <select class="form-control" id="exampleSelect1">
                        <option value="">1</option>
                        <option value="">2</option>
                    </select>
                </div>-->

                <div class="form-group">
                    <label for="zona">Zona</label>
                    <select class="form-control" id="zona" name="zona">
                        <option value="1">1</option>
                        <option value="2">2</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Guardar</button>
                <button type="reset" class="btn btn-primary">Cancelar</button>
            </form>
        </div>

    </div>
</div>
        </div>
       

</div>


