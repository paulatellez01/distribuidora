<div id="page-wrapper">

        <br>
<div class="container">
    <div class="container-fluid">
        <div class="jumbotron">
            <label><h5><b>Registrar Producto</b></h5></label>

            <br>
            <form>
                <div class="form-group">
                    <label for="user">Codigo</label>
                    <input class="form-control" type="text" name="cod" id="user" placeholder="Codigo">
                </div>

                <div class="form-group">
                    <label for="user">Nombre</label>
                    <input class="form-control" type="text" name="name" id="user" placeholder="Nombre">
                </div>

                <div class="form-group">
                    <label for="user">Marca</label>
                    <input class="form-control" type="text" name="marca" id="user" placeholder="Marca">
                </div>

                <div class="form-group">
                    <label for="user">Precio</label>
                    <input class="form-control" type="tel" name="precio" id="user" placeholder="Precio">
                </div>


                <div class="form-group">
                    <label for="tel">Iva</label>
                    <input class="form-control" type="tel" name="iva" id="iva" placeholder="Iva">
                </div>

                <div class="form-group">
                    <label for="exampleInputFile">Imagen</label>
                    <input type="file" class="form-control-file" name="image" id="exampleInputFile" aria-describedby="fileHelp">
                </div>

                <div class="form-group">
                    <label for="exampleTextarea">Carácteristicas</label>
                    <textarea class="form-control" name="carac" id="exampleTextarea" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label for="exampleSelect1">Categoria</label>
                    <select class="form-control" id="exampleSelect1">
                        <option value="">1</option>
                        <option value="">2</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Guardar</button>
                <button type="reset" class="btn btn-primary">Cancelar</button>
            </form>
        </div>

    </div>
</div>
</div>
       

    </div>
    
