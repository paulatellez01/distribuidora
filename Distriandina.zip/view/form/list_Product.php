<div id="page-wrapper">
            <br>
<div class="container">
    <div class="container-fluid">
        <div class="jumbotron">
            <label><h5><b>Listado Productos</b></h5></label>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Nombre</th>
                        <th>Precio</th>
                        <th>Categoria</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>PRO-1</td>
                        <td>Cinturon</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td><a href="#"><span class="fa fa-pencil-square-o">&nbsp;</span>Editar</a></td>
                        <td><a href="#"><span class="fa fa-trash-o">&nbsp;</span>Eliminar</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

        </div>
       

    </div>
    


