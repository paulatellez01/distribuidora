<div id="page-wrapper">
            <br>
<div class="container">
    <div class="container-fluid">
        <div class="jumbotron">
        <label><h5><b>Listado Vendedores</b></h5></label>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Email</th>
                </tr>
            </thead> <?php
            foreach ($this->modelAdmin->queryJoin('vendedor', ' inner join usuario ', " where vendedor.vendedor_usuario=usuario.usuario_id && usuario.usuario_rol='seller'") as $r )  
            { ?> <tbody>
                <tr>
                    <td><?php echo $r->vendedor_usuario; ?></td>
                    <td><?php echo $r->vendedor_nombre; ?></td>
                    <td><?php echo $r->vendedor_apellido; ?></td>
                    <td><?php echo $r->vendedor_email; ?></td>
                    <td><a href="#"><span class="fa fa-pencil-square-o">&nbsp;</span>Editar</a></td>
                    <td><a href="#"><span class="fa fa-trash-o">&nbsp;</span>Eliminar</a></td>
                </tr>
            </tbody>
            <?php  } ?>
        </table>
    </div>
</div>
</div>

</div>
       

</div>
    
