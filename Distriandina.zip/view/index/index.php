<div class="container-fluid">
    <div class="index" >
        <div class="index-info">
        
                <form action="?c=index&m=validarData" method="post">
                <div class="from-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                  <input id="user" type="text" class="form-control" name="user" placeholder="Usuario">
                </div>
                <div class="from-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                  <input id="password" type="password" class="form-control" name="password" placeholder="Contraseña">
                </div>
                <button type="submit" class="btn btn-primary">INICIAR SESION </button>
            </form>
            </div>
    </div>
</div>
