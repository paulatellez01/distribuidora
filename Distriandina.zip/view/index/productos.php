<div class="main">
<div class="review-content">
			<div class="top-header span_top">
				<div class="logo">
                                    <a href="index.html"><img src="assest/img/loguito.png" alt="" /></a>
                                        <p>Distribuidora de papeleria</p>
                                </div>
				<div class="search v-search">
					<form>
						<input type="text" value="Search.." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search..';}"/>
						<input type="submit" value="">
					</form>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="reviews-section">
                            <CENTER><h1 style="font-weight: bold">CATEGORIA</h1></center>
                                <div class="col-md-3 reviews-grids">
                                                <div class="container">
                                                     <h3 class="head">PRODUCTOS</h3>
                                                     
                                                    <div class="row">
                                                      <div class="col-sm-3">
                                                        <div class="sidebar-nav">
                                                          <div class="navbar navbar-default" role="navigation">
                                                            <div class="navbar-header">
                                                              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
                                                                <span class="sr-only">Toggle navigation</span>
                                                                <span class="icon-bar"></span>
                                                                <span class="icon-bar"></span>
                                                                <span class="icon-bar"></span>
                                                              </button>
                                                              <span class="visible-xs navbar-brand">Sidebar menu</span>
                                                            </div>
                                                            <div class="navbar-collapse collapse sidebar-navbar-collapse">
                                                              <ul class="nav navbar-nav">
                                                                <li class="active"><a href="#">Menu Item 1</a></li>
                                                                <li><a href="#">Menu Item 2</a></li>
                                                                <li><a href="#">Menu Item 3</a></li>
                                                                <li><a href="#">Menu Item 4</a></li>
                                                               
                                                              </ul>
                                                            </div><!--/.nav-collapse -->
                                                          </div>
                                                        </div>
                                                      </div>
                                                      
                                                    </div>
                                                    </div>
                                        </div>
					<div class="col-md-9 reviews-grids">
                                           
                                            <?php for($i=0; $i<=9; $i++)                                            
                                            { ?>
                                            <div class="col-md-5" reviews-grids>
						<div class="review">
							<div class="movie-pic">
								<a href="single.html"><img src="assest/img/img6.jpg" alt="" /></a>
							</div>
							<div class="review-info">
								<a class="span" href="single.html">Mochila Floral <i>Jordi Labanda</i></a>
								<p class="dirctr"><a href="">Reagan Gavin Rasquinha, </a>TNN, Mar 12, 2015, 12.47PM IST</p>								
								<p class="info">CAST:&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Will Smith, Margot Robbie, Adrian Martinez, Rodrigo Santoro, BD Wong, Robert Taylor</p>
								<p class="info">DIRECTION: &nbsp;&nbsp;&nbsp;&nbsp;Glenn Ficarra, John Requa</p>
								<p class="info">GENRE:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Crime</p>
								<p class="info">DURATION:&nbsp;&nbsp;&nbsp; &nbsp; 1 hour 45 minutes</p>
							</div>
							<div class="clearfix"></div>
						</div>						
                                            </div> 
                                            <?php } ?>
                                        </div>
                                        
                                  
					<div class="clearfix"></div>
			</div>
			</div>
		<div class="review-slider">
			 <ul id="flexiselDemo1">
			<li><img src="images/r1.jpg" alt=""/></li>
			<li><img src="images/r2.jpg" alt=""/></li>
			<li><img src="images/r3.jpg" alt=""/></li>
			<li><img src="images/r4.jpg" alt=""/></li>
			<li><img src="images/r5.jpg" alt=""/></li>
			<li><img src="images/r6.jpg" alt=""/></li>
		</ul>
			<script type="text/javascript">
		$(window).load(function() {
			
		  $("#flexiselDemo1").flexisel({
				visibleItems: 6,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,    		
				pauseOnHover: false,
				enableResponsiveBreakpoints: true,
				responsiveBreakpoints: { 
					portrait: { 
						changePoint:480,
						visibleItems: 2
					}, 
					landscape: { 
						changePoint:640,
						visibleItems: 3
					},
					tablet: { 
						changePoint:768,
						visibleItems: 3
					}
				}
			});
			});
		</script>
		<script type="text/javascript" src="js/jquery.flexisel.js"></script>	
		</div>	
