<?php
class security
{
    private $pdo;
    public function __construct() {
        try {
            $this->pdo=database::conectar();
        } catch (Exception $e) {
            die ($e->getMessage());
        }
    }
    
    public function iniciarSesion($user)
    {
        
        $_SESSION['USUARIO']=$user['usuario'];
        $_SESSION['PASSWORD']=$user['password'];
        $_SESSION['ROL']=$user['rol'];
       
        
    }
    
    public function destruir()
    {
        unset($_SESSION['USUARIO']);
        unset($_SESSION['PASSWORD']);
        unset($_SESSION['ROL']);       
        session_destroy();
    }
    public function validarSesion()
    {
        if(!isset($_SESSION['USUARIO']))
        {
            header("location:?c=index&m=home");
        }
    }
}