<?php

class admin {
    
    private $pdo;
    
    public function queryId($table, $condition){
        try {
               $stm=$this->pdo->prepare("SELECT * FROM ".$table,$condition);
               $stm->execute();
               return $stm->fetchAll(PDO::FETCH_OBJ);
           } catch (Exception $e) {
               die($e->getMessage());
           }
    }
    public function queryJoin($table, $join, $condition){
           try {
               echo "SELECT * FROM ".$table,$join,$condition;
               $stm=$this->pdo->prepare("SELECT * FROM ".$table,$join,$condition);
               $stm->execute();
               return $stm->fetchAll(PDO::FETCH_OBJ);
           } catch (Exception $e) {
               die($e->getMessage());
           }
    }
    public function queryLike($table,$condition){
        try {
            $stm=$this->pdo->prepare("SELECT * FROM ".$table,$condition);
            $stm->execute();
            return $stm->fetchAll(PDO::FETCH_OBJ);
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
     public function insert($table,$camp,$values){
        try {
            echo "INSERT INTO ".$table."".$camp."".$values;
            $stm=$this->pdo->prepare("INSERT INTO ".$table."".$camp."".$values);
            $stm->execute();
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
     public function delete($table,$condition){
         try {
            $stm=$this->pdo->prepare("DELETE FROM ".$table,$condition);
            $stm->execute();
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
     public function update($table,$sets,$condition){
         try {
            $stm=$this->pdo->prepare("UPDATE ".$table,$sets,$condition);
            $stm->execute();
        } catch (Exception $e) {
            die($e->getMessage());
        }
    }
    
    
}
