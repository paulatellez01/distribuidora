<?php

class index
{
    
    private $pdo;
    
    public function __construct() 
    {
        try
        {
           $this->pdo=  database::conectar();
        } catch (Exception $e) {
            die($e->getMessage());
        }
        
    }
    
    public function queryId($usuario)
    {
        try
        {
            $stm=$this->pdo->prepare("SELECT * FROM usuario WHERE usuario_id='$usuario'");
            $stm->execute();
            //PDOP es (persistence data object) patron de diseño
            return $stm->fetchAll(PDO::FETCH_OBJ);
        } catch (Exception $e) {
            die ($e->getMessage());
        }
        
    }
    
}